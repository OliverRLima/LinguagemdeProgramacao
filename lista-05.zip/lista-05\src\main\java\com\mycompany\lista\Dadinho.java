/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

import java.util.Random;

/**
 *
 * @author olive
 */
public class Dadinho {

    Random gerador = new Random();

    Integer dado1;
    Integer dado2;
    Integer vitoriasDado1 = 0;
    Integer vitoriasDado2 = 0;
    String resultado;
    String resultado2;

    public void sortearDados() {
        dado1 = gerador.nextInt(7);
        dado2 = gerador.nextInt(7);
    }

    public void devolverValor() {
        if (dado1 > dado2) {
            vitoriasDado1++;
            resultado = "O Dadinho 1 venceu";
        } else if (dado2 > dado1) {
            vitoriasDado2++;
            resultado = "O Dadinho 2 venceu";
        } else {
            resultado = "Empatou";
        }
    }

    public void devolverPlacar() {
        resultado2 = "Vitórias do Dadinho 1: " + vitoriasDado1 + "/Vitórias do Dadinho 2: " + vitoriasDado2;
    }
}
