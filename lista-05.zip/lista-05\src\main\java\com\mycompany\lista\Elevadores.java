/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

/**
 *
 * @author olive
 */
public class Elevadores {
    Integer pessoasElevador = 0;
    Integer pesoElevador = 0;
    
    public void entrarHomem(){
        pesoElevador += 90;
        pessoasElevador++;
    }
    
    public void entrarMulher(){
        pesoElevador += 65;
        pessoasElevador++;
    }
    
    public void entrarCrianca(){
        pesoElevador += 40;
        pessoasElevador++;
    }
}
