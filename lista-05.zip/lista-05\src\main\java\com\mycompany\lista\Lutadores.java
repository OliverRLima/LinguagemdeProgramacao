/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

/**
 *
 * @author olive
 */
public class Lutadores {

    Integer vidaLutador1 = 100;
    Integer vidaLutador2 = 100;

    public void apanharLutador1() {
        if (vidaLutador2 > 0) {
            if (vidaLutador1 < 10) {
                vidaLutador1 = 0;
            } else {
                vidaLutador1 -= 10;
            }
        }
    }

    public void apanharLutador2() {
        if (vidaLutador1 > 0) {
            if (vidaLutador2 < 10) {
                vidaLutador2 = 0;
            } else {
                vidaLutador2 -= 10;
            }
        }
    }

    public void concentrarLutador1() {
        if (vidaLutador2 > 0) {
            if (vidaLutador1 > 0) {
                vidaLutador1 += 2;
            }
        }

    }

    public void concentrarLutador2() {
        if (vidaLutador1 > 0) {
            if (vidaLutador2 > 0) {
                vidaLutador2 += 2;
            }
        }

    }
}
