/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;
import java.util.Scanner;
/**
 *
 * @author olive
 */
public class CalculadoraSalario {
    public void CalcularSalario(){
        Double salarioBruto;
        Double porcentoImposto;
        
        Scanner leitor = new Scanner(System.in);
        
        System.out.println("\n\n");
        System.out.println("Calculado meu salário líquido");
        
        System.out.println("Insira o valor do seu salário bruto");
        salarioBruto = leitor.nextDouble();
        
        System.out.println("Insira a porcentagem descontada pelo imposto");
        porcentoImposto = leitor.nextDouble();
        
        System.out.println("O seu salário líquido será de R$" + (salarioBruto - (salarioBruto * (porcentoImposto / 100 ))));
        
    }
}
