/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;
import java.util.Scanner;
/**
 *
 * @author olive
 */
public class Idade {
    public void descobrirIDade(){
        String nome;
        Integer anoNascimento;
        
        Scanner leitor = new Scanner(System.in);
        
        System.out.println("\n\n");
        System.out.println("Descubra sua idade em 2030");
        System.out.println("Primeiro digite seu nome");
        nome = leitor.nextLine();
        System.out.println("Olá, " + nome + "! Qual o ano de seu nascimento?");
        anoNascimento = leitor.nextInt();
        System.out.println("Em 2030 você terá " + (2030 - anoNascimento) + " anos");
       
    }
}
