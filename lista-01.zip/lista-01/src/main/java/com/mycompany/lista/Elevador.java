/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;
import java.util.Scanner;
/**
 *
 * @author olive
 */
public class Elevador {
    public void pesoElevador(){
        Double limitePeso;
        Integer limitePessoasUmElevador;
        Double pesoPPessoa;
        Double pesoSPessoa;
        Double pesoTPessoa;
        
        Scanner leitor = new Scanner(System.in);
        
        System.out.println("\n\n");
        System.out.println("Descubra o número de Pessoas nessa viagem de elevador");
        
        System.out.println("Insira o limite de peso do elevador em Kg");
        limitePeso = leitor.nextDouble();
        
        System.out.println("Insira agora o limite de pessoas no elevador");
        limitePessoasUmElevador = leitor.nextInt();
        
        System.out.println("Insira o peso da primeira pessoa a entrar no elevador");
        pesoPPessoa = leitor.nextDouble();
        
        System.out.println("Insira o peso da segunda pessoa a entrar no elevador");
        pesoSPessoa = leitor.nextDouble();
        
        System.out.println("Insira o peso da terceira pessoa a entrar no elevador");
        pesoTPessoa = leitor.nextDouble();
        
        System.out.println("Entraram 3 pessoas no elevador, no qual cabem " + limitePessoasUmElevador + " pessoas");
        System.out.println("O peso total no elevador é de " + (pesoPPessoa + pesoSPessoa + pesoTPessoa) + "Kg, sendo que ele suporta " + limitePeso + "Kg");
        
    }
}
