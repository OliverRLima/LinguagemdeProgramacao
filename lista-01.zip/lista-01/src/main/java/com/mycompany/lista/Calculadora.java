/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

import java.util.Scanner;

/**
 *
 * @author olive
 */
public class Calculadora {
    public static void main(String[] args) {
        Double pnumero;
        Double snumero;
        // A soma de números do tipo Double gera resultados do tipo Double
        Scanner leitor = new Scanner(System.in);
        
        System.out.println("Calculadora Simples de dois números");
        System.out.println("Digite o primeiro número");
        pnumero = leitor.nextDouble();
        System.out.println("Digite o segundo número");
        snumero = leitor.nextDouble();
        
        System.out.println("A soma dos dois números resulta em " + (pnumero + snumero));
        System.out.println("A subtração dos dois números resulta em " + (pnumero - snumero));
        System.out.println("A multiplicação dos dois números resulta em " + (pnumero * snumero));
        System.out.println("A divisão dos dois números resulta em " + (pnumero / snumero));
        
        Idade Idade = new Idade();
        Idade.descobrirIDade();
        
        Elevador Elevador = new Elevador();
        Elevador.pesoElevador();
        
        CalculadoraTroco CalcularTroco = new CalculadoraTroco();
        CalcularTroco.valorTroco();
        
        CalculadoraSalario CalculandoSalario = new CalculadoraSalario();
        CalculandoSalario.CalcularSalario();
    }
}
