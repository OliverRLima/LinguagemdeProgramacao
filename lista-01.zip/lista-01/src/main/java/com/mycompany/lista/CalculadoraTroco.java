/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;
import java.util.Scanner;
/**
 *
 * @author olive
 */
public class CalculadoraTroco {
    public void valorTroco(){
        Double umProduto;
        Integer qtdProduto;
        Double valorPago;
        
        Scanner leitor = new Scanner(System.in);
        
        System.out.println("\n\n");
        System.out.println("Calculando o valor do troco");
        
        System.out.println("Insira o valor unitário do produto");
        umProduto = leitor.nextDouble();
        
        System.out.println("Insira a quantidade de produtos comprados");
        qtdProduto = leitor.nextInt();
        
        System.out.println("Insira o valor dado pelo cliente");
        valorPago = leitor.nextDouble();
     
        System.out.println("Seu troco será de R$" + (valorPago - (umProduto * qtdProduto)));
        
    }
}
