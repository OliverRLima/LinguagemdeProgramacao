/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;
import java.util.Scanner;
/**
 *
 * @author olive
 */
public class CalculadoraPizza {
    public static void main(String[] args) {
        
        Double precoPizza;
        String saborPizza;
        Integer pessoasPizza, valorMaximoPagar;
        
        Scanner leitorNumeros = new Scanner(System.in);
        Scanner leitorString = new Scanner(System.in);
                
        System.out.println("Insira o valor de uma pizza");
        precoPizza = leitorNumeros.nextDouble();
        
        System.out.println("Insira o sabor da pizza");
        saborPizza = leitorString.nextLine();
        
        System.out.println("Quantas pessoas vão pagar?");
        pessoasPizza = leitorNumeros.nextInt();
        
        System.out.println("Qual valor máximo que aceitam passar?");
        valorMaximoPagar = leitorNumeros.nextInt();
        
        if (precoPizza < (valorMaximoPagar * pessoasPizza)){
            
            System.out.format("A pizza de %s será dividida entre %d pessoas. R$%.2f p/cada",saborPizza, pessoasPizza, (precoPizza / pessoasPizza));
            
        } else {
            
            System.out.format("Deu ruim no racha. A pizza deveria custar no máximo %d",(valorMaximoPagar * pessoasPizza));
            
        }
        
        /*
        Sorveteria sorveteria = new Sorveteria();
        sorveteria.casa();
        */
}
    
}
