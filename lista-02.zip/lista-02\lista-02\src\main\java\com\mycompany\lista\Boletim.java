/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;
import java.util.Scanner;
/**
 *
 * @author Aluno
 */
public class Boletim {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        
        System.out.println("Insira a sua primeira nota");
        Double primeiraNota = leitor.nextDouble();
        
        System.out.println("Insira a sua segunda nota");
        Double segundaNota = leitor.nextDouble();
        
        System.out.println("Insira a sua terceira nota");
        Double terceiraNota = leitor.nextDouble();
        
        Double notaFinal = (primeiraNota + segundaNota + terceiraNota) / 3;
        if(notaFinal >= 7){
            System.out.println("Passou direto");
        }   else if(notaFinal < 5){
            System.out.println("Reprovado direto");
        } else {
            System.out.println("Tem direito de fazer uma prova de recuperação");
        }
    }
}
