/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

import java.util.Scanner;

/**
 *
 * @author olive
 */
public class Sorveteria {
    public static void main(String[] args) {
        
    
    //public void casa(){
           
        Scanner leitor = new Scanner(System.in);
        
        System.out.println("\n\nQual das opções você deseja? Temos casquinha, sundae e milkshake");
        String escolha = leitor.nextLine();
    
        switch (escolha){
            case "casquinha": System.out.println("A casquinha custa R$2,00");
                break;
            case "sundae": System.out.println("O sundae custa R$5,00");
                break;
            case "milkshake": System.out.println("O milkshake custa 7,00");
                break;
            default: System.out.println("Não temos essa opção");
                break;
        }
    //}
    }
}
    