package com.mycompany.lista;
import java.util.Scanner;
/**
 *
 * @????
 */
public class indiceMassaCorporal {

    public static void main(String[] args) {
        Scanner leitorNumero = new Scanner(System.in);
        Scanner leitorString = new Scanner(System.in);
        
        System.out.println("Insira o seu sexo masculino ou feminino");
        String sexo = leitorString.nextLine();
        
        System.out.println("Insira a sua altura em metros");
        Double altura = leitorNumero.nextDouble();
        
        System.out.println("Insira o seu peso em Kg");
        Double peso = leitorNumero.nextDouble();
        
        Double imc = peso/(altura * altura);
        
        switch(sexo){
            case "masculino":
                if(imc < 20.7){
                    System.out.println("Você está abaixo do peso");
                } else if(imc < 26.4){
                    System.out.println("Você está no peso normal");
                } else if(imc < 27.8){
                    System.out.println("Você está marginalmente acima do peso");
                } else if(imc < 31.1){
                    System.out.println("Você está acima do peso ideal");
                } else {
                    System.out.println("Você está obeso");
                }
                
                break;
            case "feminino":
                if(imc < 19.1){
                    System.out.println("Você está abaixo do peso");
                } else if(imc < 25.8){
                    System.out.println("Você está no peso normal");
                } else if(imc < 27.3){
                    System.out.println("Você está marginalmente acima do peso");
                } else if(imc < 32.3){
                    System.out.println("Você está acima do peso ideal");
                } else {
                    System.out.println("Você está obeso");
                }
                
                break;
            default: System.out.println("Escolha inválida");
                break;
        }       
    }
}
    

