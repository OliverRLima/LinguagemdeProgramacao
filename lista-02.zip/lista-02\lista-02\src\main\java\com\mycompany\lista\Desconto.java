/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;
import java.util.Scanner;
/**
 *
 * @author Aluno
 */
public class Desconto {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        
        System.out.println("Insira o valor do produto");
        Double valorProduto = leitor.nextDouble();
        
        System.out.println("Insira o código de desconto");
        Integer codigoDesconto = leitor.nextInt();
        
        switch(codigoDesconto){
            case 1: System.out.format("O produto custa R$%.2f, porem com esse desconto fica R$%.2f",valorProduto, (valorProduto - (valorProduto * 0.05)));
                break;
            case 2: System.out.format("O produto custa R$%.2f, porem com esse desconto fica R$%.2f",valorProduto, (valorProduto - (valorProduto * 0.1)));
                break;
            case 3: System.out.format("O produto custa R$%.2f, porem com esse desconto fica R$%.2f",valorProduto, (valorProduto - (valorProduto * 0.2)));
                break;
            case 4: System.out.format("O produto custa R$%.2f, porem com esse desconto fica R$%.2f",valorProduto, (valorProduto - (valorProduto * 0.5)));
                break;
            default: System.out.println("Código inserido é inválido");
                break;
        }
    }
}
