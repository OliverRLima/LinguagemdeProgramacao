/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio1;

/**
 *
 * @author olive
 */
public class Clube {

    private Integer numeroVitorias = 0;
    private Integer numeroEmpates = 0;
    private Integer numeroDerrotas = 0;
    private Integer pontuacao = 0;
    private String mensagemPartida;

    public void vencer() {
        this.numeroVitorias++;
        this.pontuacao += 3;
        this.mensagemPartida = "venceu";
    }

    public void empatar() {
        this.numeroEmpates++;
        this.pontuacao++;
        this.mensagemPartida = "empatou";
    }

    public void perder() {
        this.numeroDerrotas++;
        this.mensagemPartida = "perdeu";
    }

    public String getStringResultado() {
        return "Vitórias: " + this.numeroVitorias + " - Derrotas: " + this.numeroDerrotas +
               " - Empates: " + this.numeroEmpates;
    }
    
    public String getStringPontos(){
        return "Pontuação: " + this.pontuacao + " pontos";
    }
    
    
    // gets caso seja necessário pegar somente o valor do atributo
    
    public Integer getNumeroVitorias(){
        return this.numeroVitorias;
    }
    
    public Integer getNumeroEmpates(){
        return this.numeroEmpates;
    }
    
    public Integer getNumeroDerrotas(){
        return this.numeroDerrotas;
    }
    
    public Integer getPontos(){
        return this.pontuacao;
    }
    
    public String getMensagemPartida(){
        return this.mensagemPartida;
    }
}
