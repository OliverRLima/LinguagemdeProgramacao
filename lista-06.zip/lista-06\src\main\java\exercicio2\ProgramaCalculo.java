/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio2;

/**
 *
 * @author olive
 */
public class ProgramaCalculo {
    
    public static void main(String[] args) {
        
        Calculadora calculadora = new Calculadora();
        
        System.out.println("Iniciando Programa calculadora...");
        
        calculadora.setPrimeiroNumero(10.0);
        calculadora.setSegundoNumero(2.0);
        
        calculadora.somar();
        System.out.println("\n10 + 2 = " + calculadora.getResultadoOperacoes());
                
        calculadora.subtrair();
        System.out.println("10 - 2 = " + calculadora.getResultadoOperacoes());
        
        calculadora.multiplicar();
        System.out.println("10 * 2 = " + calculadora.getResultadoOperacoes());
        
        calculadora.dividir();
        System.out.println("10 / 2 = " + calculadora.getResultadoOperacoes());
        
        System.out.println("\nPrograma Encerrado");
    }

}
