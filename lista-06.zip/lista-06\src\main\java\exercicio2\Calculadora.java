/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio2;

/**
 *
 * @author olive
 */
public class Calculadora {
    private Double primeiroNumero;
    private Double segundoNumero;
    private Double resultadoOperacoes;
    
    public void setPrimeiroNumero(Double numero){
        this.primeiroNumero = numero;
    }
    
    public void setSegundoNumero(Double numero){
        this.segundoNumero = numero;
    }
    
    public void somar(){
        this.resultadoOperacoes = this.primeiroNumero + this.segundoNumero;
    }
    
    public void subtrair(){
        this.resultadoOperacoes = this.primeiroNumero - this.segundoNumero;
    }
    
    public void multiplicar(){
        this.resultadoOperacoes = this.primeiroNumero * this.segundoNumero;
    }
    
    public void dividir(){
        this.resultadoOperacoes = this.primeiroNumero / this.segundoNumero;
    }
    
    public double getResultadoOperacoes(){
        return this.resultadoOperacoes;
    }
   
}
