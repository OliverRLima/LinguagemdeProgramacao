/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio1;

import java.util.Random;

/**
 *
 * @author olive
 */
public class ProgramaCampeonato {

    public static void main(String[] args) {

        Random gerador = new Random();
        Clube barcelona = new Clube();
        Clube realMadrid = new Clube();

        Integer resultadoBarcelona;
        Integer resultadoRealMadrid;

        System.out.println("Começando a temporada!");

        for (Integer contador = 0; contador < 5; contador++) {

            resultadoBarcelona = gerador.nextInt(3);

            switch (resultadoBarcelona) {
                case 0:
                    barcelona.vencer();
                    break;
                case 1:
                    barcelona.empatar();
                    break;
                case 2:
                    barcelona.perder();
                    break;
                default:
                    break;
            }

            resultadoRealMadrid = gerador.nextInt(3);

            switch (resultadoRealMadrid) {
                case 0:
                    realMadrid.vencer();
                    break;
                case 1:
                    realMadrid.empatar();
                    break;
                case 2:
                    realMadrid.perder();
                    break;
                default:
                    break;
            }

            System.out.println("\nBarcelona " + barcelona.getMensagemPartida() + " nessa rodada");
            System.out.println("Real Madrig " + realMadrid.getMensagemPartida() + " nessa rodada");

            System.out.println("\nBarcenola pontos: " + barcelona.getPontos());
            System.out.println("Real Madrid pontos: " + realMadrid.getPontos());

            System.out.println("\n ---------------------------------------------------------");

        }

        System.out.println("Final de Temporada:");

        System.out.println("\nBarlona teve " + barcelona.getStringResultado());
        System.out.println(barcelona.getStringPontos());

        System.out.println("\nReal Madrid teve " + realMadrid.getStringResultado());
        System.out.println(realMadrid.getStringPontos());
    }

}
