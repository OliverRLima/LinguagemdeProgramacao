/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio3;
import java.util.Random;

/**
 *
 * @author olive
 */
public class ProgramaEleicao {
    
    public static void main(String[] args) {
        UrnaEletronica urnaEletronica = new UrnaEletronica();
        Random gerador = new Random();
        
        Integer votosAleatorios;
        
        System.out.println("Começou a eleição: ");
        
        for(Integer contador = 0; contador < 8; contador++){
            votosAleatorios = gerador.nextInt(2);
            
            switch (votosAleatorios){
                case 0: urnaEletronica.votarPrimeiroCandidato();
                    break;
                case 1: urnaEletronica.votarSegundoCadidato();
                    break;
                default:
                    break;
            }
            
            System.out.println("\n" + urnaEletronica.getMensagem() + " recebeu 1 voto");
            System.out.println("Total de votos Candidato 1: "  +urnaEletronica.getVotosPrimeiroCandidato());
            System.out.println("Total de votos Candidato 2: " + urnaEletronica.getVotosSegundoCandidato());

        }
        
        System.out.println("\nEleição encerrada!");
        
        urnaEletronica.encerrarVotacao();
        
        System.out.println("----------------------------------");
        System.out.println("Votos totais: " + urnaEletronica.getNumeroVotos());
        System.out.println("Resultado: " + urnaEletronica.getResultado());
    }
}
