/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio3;

/**
 *
 * @author olive
 */
public class UrnaEletronica {

    private Integer primeiroCandidato = 0;
    private Integer segundoCandidato = 0;
    private Integer numeroVotos = 0;
    private boolean naoPodeVotar;
    private String resultado;
    private String mensagem;

    public void votarPrimeiroCandidato() {

        if (naoPodeVotar == false) {
            this.primeiroCandidato++;
            this.numeroVotos++;
            this.mensagem = "Candidato 1";
        }

    }

    public void votarSegundoCadidato() {
        
        if (naoPodeVotar == false) {
            this.segundoCandidato++;
            this.numeroVotos++;
            this.mensagem = "Candidato 2";
        }

    }

    public void encerrarVotacao() {
        this.naoPodeVotar = true;
        if(this.primeiroCandidato > this.segundoCandidato){
            this.resultado = "candidato 1 venceu";
        } else if (this.primeiroCandidato < this.segundoCandidato){
            this.resultado = "candidato 2 venceu";
        } else {
            this.resultado = "empatou";
        }
    }

    public int getVotosPrimeiroCandidato(){
        return this.primeiroCandidato;
    }
    
    public int getVotosSegundoCandidato(){
        return this.segundoCandidato;
    }
    
    public Integer getNumeroVotos() {
        return this.numeroVotos;
    }

    public String getResultado() {
        return this.resultado;
    }
    
    public String getMensagem(){
        return this.mensagem;
    }
}
