/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

import java.util.Scanner;

/**
 *
 * @author olive
 */
public class Votacao {

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        Integer SaborMussarela = 0, SaborCalabresa = 0, SaborQuatroQueijos = 0;
        String saborFavorito = "";

        for (Integer contador = 0; contador < 10; contador++) {
            System.out.println("\n" + (contador + 1) + "º Votante\n"
                    + "Qual sabor de pizza voçê mais gosta? \n"
                    + "Mussarela (digite 5)\n"
                    + "Calabresa (digite 25) \n"
                    + "Quatro Queijos (digite 50)");
            Integer sabor = leitor.nextInt();

            switch (sabor) {
                case 5:
                    SaborMussarela++;
                    break;
                case 25:
                    SaborCalabresa++;
                    break;
                case 50:
                    SaborQuatroQueijos++;
                    break;
                default:
                    System.out.println("Valor inserido não corresponde a um sabor válido");
                    break;

            }

        }

        if (SaborMussarela > SaborCalabresa && SaborMussarela > SaborQuatroQueijos) {
            saborFavorito = "a pizza favorita segundo votação é a de Mussarela";
        } else if (SaborCalabresa > SaborMussarela && SaborCalabresa > SaborQuatroQueijos) {
            saborFavorito = "a pizza favorita segundo votação é a de Calabresa";
        } else if (SaborQuatroQueijos > SaborMussarela && SaborQuatroQueijos > SaborCalabresa) {
            saborFavorito = "a pizza favorita segundo votação é a de Quatro Queijos";
        } else {
            saborFavorito = "ocorreu um empate na votação e não há uma pizza favorita";
        }

        System.out.format("\nMussarela recebeu %d votos \nCalabresa recebeu %d votos \nQuatro queijos recebeu %d votos", SaborMussarela, SaborCalabresa, SaborQuatroQueijos);
        System.out.format("\nSendo assim %s", saborFavorito);
    }
}
