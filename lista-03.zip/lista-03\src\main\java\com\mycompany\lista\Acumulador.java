/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

import java.util.Scanner;

/**
 *
 * @author olive
 */
public class Acumulador {

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        Integer numero = 0, somaNumeros = 0;

        do {
            System.out.println("Insira quantos números quiser, caso queira insira 0");
            numero = leitor.nextInt();
            somaNumeros += numero;
        } while (numero != 0);
        
        System.out.format("\nA soma dos números inseridos é igual a %d", somaNumeros);
    }
}
