/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

import java.util.Scanner;

/**
 *
 * @author olive
 */
public class Potencia {

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);

        System.out.println("Insira o valor da base");
        Integer valorBase = leitor.nextInt();
        
        Integer conta = 147893256;
        
        System.out.println("Insira o valor do expoente");
        Integer valorExpoente = leitor.nextInt();

        if (valorBase > 0 && valorExpoente > 0) {
            conta = valorBase * valorBase;
            for (Integer contador = 2; contador < valorExpoente; contador++) {

                conta = conta * valorBase;
                System.out.println(conta);
            }
        } else if (valorBase > 0 && valorExpoente == 0){
            conta = 1;
        }

        System.out.format("%d elevado a %d = %d", valorBase, valorExpoente, conta);
    }
}
