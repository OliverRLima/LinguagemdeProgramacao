/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;
import java.util.Scanner;   

/**
 *
 * @author olive
 */
public class Tabuada {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        
        System.out.println("Insira um número e veja a tabuada dele do 0 ao 10");
        Integer numero = leitor.nextInt();
        
        for(Integer contador = 0; contador < 11; contador++){
            System.out.format("\n%d x %d = %d",numero, contador, (numero * contador));
        }
    }
}
