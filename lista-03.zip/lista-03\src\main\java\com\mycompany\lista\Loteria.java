/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;
import java.util.Scanner;
import java.util.Random;


/**
 *
 * @author olive
 */
public class Loteria {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        Random gerador = new Random();
        Integer contador = 0, aleatorio, numero = 0;
        
        System.out.println("Insira um número de 0 a 10 e veja se é o mesmo que eu sorteei");
        
        do{
            aleatorio = gerador.nextInt(11);
            numero = leitor.nextInt();
            contador++;
            System.out.format("O número que eu sorteei foi %d \n \n",aleatorio);
        } while (numero != aleatorio);
        
        if(contador > 10){
            System.out.println("É melhor você ser trabalhador");
        } else if (contador <= 3){
            System.out.println("Você é MUITO sortudo");
        } else {
            System.out.println("Você é sortudo");
        }
    }
}
