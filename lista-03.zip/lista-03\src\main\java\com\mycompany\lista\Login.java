/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;
import java.util.Scanner;

/**
 *
 * @author olive
 */
public class Login {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        String login,senha;
        
        do{
            System.out.println("\nLogin:");
            login = leitor.nextLine();
            
            System.out.println("Senha:");
            senha = leitor.nextLine();
            
            if(login.equals("admin") && senha.equals("#Bandtec")){
                System.out.println("Login realizado com sucesso");
            } else {
                System.out.println("Login e/ou senha inválidos");
            }
        } while(!"admin".equals(login) && !"#Bandtec".equals(senha));
    }
}
