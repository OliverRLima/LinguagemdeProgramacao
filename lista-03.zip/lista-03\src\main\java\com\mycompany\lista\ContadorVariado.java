    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

/**
 *
 * @author olive
 */
public class ContadorVariado {
    public static void main(String[] args) {
        Double numero = 0.15;
        while(numero < 5.00){
            System.out.format("\n %.2f",numero);
            numero+= 0.15;
        }
        
        
        
    }
}
