/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author olive
 */
public class Sorteio {

    public static void main(String[] args) {
        Random gerador = new Random();
        Scanner leitor = new Scanner(System.in);
        Integer combinou = 0, sorteado, contadorImpar = 0, contadorPar = 0;

        System.out.println("Insira um número de 0 a 100");
        Integer escolhido = leitor.nextInt();

        for (Integer contador = 0; contador < 200; contador++) {
            sorteado = gerador.nextInt(101);

            if (combinou == 0) {

                if (sorteado == escolhido) {
                    System.out.format("\nO seu número foi sorteado na %d tentativa", contador);
                    combinou++;
                }

            }

            if (sorteado % 2 == 0) {
                contadorPar++;
            } else {
                contadorImpar++;
            }

        }

        System.out.format("\nDas 200 tentativas de sorteio %d foram par e %d foram impar", contadorPar, contadorImpar);
    }
}
