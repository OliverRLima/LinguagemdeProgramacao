/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

/**
 *
 * @author olive
 */
public class NumerosPares {
    public static void main(String[] args) {
        Integer contador = 0;
        while(contador <= 40){
            if(contador == 0){
                contador=+2;
            }
            System.out.println(contador);
            contador+=2;
        }
    }
}
