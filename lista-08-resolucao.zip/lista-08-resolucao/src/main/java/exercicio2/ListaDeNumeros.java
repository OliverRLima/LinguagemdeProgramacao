/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author olive
 */
public class ListaDeNumeros {
    
    public static void main(String[] args) {
        
        Scanner leitor = new Scanner(System.in);
        
        List<Integer> listaNumeros = new ArrayList();
        
        Integer somatoriaListaNumeros = 0;
        Integer menorNumeroLista = 0;
        Integer maiorNumeroLista = 0;
        
        Integer numero = 1;
        Integer numeroMaior = 0;
        Integer numeroMenor = 0;
        
        System.out.println("Digite números abaixo. Quando quiser parar digite zero");
        
        while(numero != 0){
            numero = leitor.nextInt();
            listaNumeros.add(numero);
        }
        
        
        for(Integer numerosLista : listaNumeros){
            if(numeroMaior < numerosLista){
                maiorNumeroLista = numerosLista;
            }
            
            if(numeroMenor > numerosLista){
                menorNumeroLista = numerosLista;
            }
            
            somatoriaListaNumeros += numerosLista;
            numeroMaior = numerosLista;
            numeroMenor = numerosLista;
        }
        
        System.out.println("\nNúmeros pares presentes na lista");
        for(Integer numerosLista : listaNumeros){
            if(numerosLista %2 == 0){
                System.out.format("%d ",numerosLista);
            }          
        }
        
        System.out.println("\nNúmeros impares presentes na lista");
        for(Integer numerosLista : listaNumeros){
            if(numerosLista %2 != 0){
                System.out.format("%d ",numerosLista);
            }          
        }
        
        System.out.println("\nSomatoria de todos os números presentes na lista");
        System.out.println(somatoriaListaNumeros);
        
        System.out.println("\nMenor número presente na lista");
        System.out.println(menorNumeroLista);
        
        System.out.println("\nMaior número presente na lista");
        System.out.println(maiorNumeroLista);
        
    }

}
