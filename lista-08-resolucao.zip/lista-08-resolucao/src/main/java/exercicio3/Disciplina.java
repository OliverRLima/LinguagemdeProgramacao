/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio3;

/**
 *
 * @author olive
 */
public class Disciplina {
    
    private Integer quantFalta;
    private String nome;
    private Double notaContinuada;
    private Double notaIntegrada;
    private Double media;
    private Boolean aprovado = false;

    public void setQuantFalta(Integer quantFalta) {
        this.quantFalta = quantFalta;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setNotaContinuada(Double notaContinuada) {
        this.notaContinuada = notaContinuada;
    }

    public void setNotaIntegrada(Double notaSemestral) {
        this.notaIntegrada = notaSemestral;
    }

    public void calcularMedia(){
        this.media = (this.notaContinuada * 0.4) + (this.notaIntegrada * 0.6);
    }

    public void verificarAprovacao() {
        if(this.media > 6.0 && this.quantFalta <= 15){
            this.aprovado = true;
        }
    }
    
    public Integer getQuantFalta() {
        return this.quantFalta;
    }

    public String getNome() {
        return this.nome;
    }

    public Double getNotaContinuada() {
        return this.notaContinuada;
    }

    public Double getNotaIntegrada() {
        return this.notaIntegrada;
    }

    public Double getMedia() {
        return this.media;
    }

    public String getAprovado() {
        if(this.aprovado == true){
            return "Aprovado!";
        } else {
            return "Reprovado!";
        }
        
    }
    
    @Override
    public String toString(){
        return "Nome da disciplina: " + this.nome;
    }
}
