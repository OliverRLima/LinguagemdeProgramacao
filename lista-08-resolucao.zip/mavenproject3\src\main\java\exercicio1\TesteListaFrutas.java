/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author olive
 */
public class TesteListaFrutas {
    public static void main(String[] args) {
        
        Scanner lerDados = new Scanner(System.in);
        
        List<String> listaFruta = new ArrayList();
        listaFruta.add("abacate");
        listaFruta.add("abacaxi");
        listaFruta.add("banana");
        listaFruta.add("morango");
        listaFruta.add("melancia");
        listaFruta.add("maçã");
        
        System.out.println("Escreva a fruta desejada");
        String pesquisado = lerDados.nextLine();
        Boolean achou = false;
        
        
        for(String pesquisa: listaFruta){
            if(listaFruta.contains(pesquisado)){
                achou = true;
            }
        }
        
        if(achou == true){
            System.out.println(String.format("A fruta %s existe na lista", pesquisado));
        } else {
            System.out.println(String.format("A fruta %s não existe na lista", pesquisado));
        }
        
    }
}
