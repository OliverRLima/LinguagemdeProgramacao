/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio3;

/**
 *
 * @author olive
 */
public class ProgramaAluno {
   
    public static void main(String[] args) {
    
        Aluno aluno = new Aluno(50000, "Diego Brito");
        Disciplina dcp1 = new Disciplina();
        Disciplina dcp2 = new Disciplina();
        
        dcp1.setNome("Linguagem de programação");
        dcp1.setQuantFalta(2);
        dcp1.setNotaContinuada(10.0);
        dcp1.setNotaIntegrada(9.5);
        dcp1.calcularMedia();
        dcp1.verificarAprovacao();
        
        dcp2.setNome("Banco de Dados");
        dcp2.setQuantFalta(4);
        dcp2.setNotaContinuada(6.5);
        dcp2.setNotaIntegrada(2.4);
        dcp2.calcularMedia();
        dcp2.verificarAprovacao();

        
        aluno.adiciona(dcp1);
        aluno.adiciona(dcp2);
        
        System.out.println("------SITUAÇÂO DO ALUNO------\n");
        System.out.println(aluno.exibirBoletim("Linguagem de programação"));
        System.out.println("\n" + aluno.exibirBoletim("Banco de Dados"));
        System.out.println("\n------SITUAÇÂO DO ALUNO------");
    }

}
