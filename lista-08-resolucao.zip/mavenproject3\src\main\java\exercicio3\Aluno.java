/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio3;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author olive
 */
public class Aluno {

    private Integer ra;
    private String nome;
    private List<Disciplina> listaDisciplinas;

    public Aluno(Integer ra, String nome) {
        this.listaDisciplinas = new ArrayList<>();
        this.ra = ra;
        this.nome = nome;
    }

    public String exibirBoletim(String nomeDisciplina) {
        for (Integer contador = 0; contador < listaDisciplinas.size(); contador++) {
            
            Disciplina materiaSelecionada = (Disciplina) listaDisciplinas.get(contador);
            
            if (materiaSelecionada.getNome()== nomeDisciplina) {
                
                String mensagem = "Nome da disciplina: " + materiaSelecionada.getNome() + "\n"
                        + "Nota continuada: " + materiaSelecionada.getNotaContinuada() + "\n"
                        + "Nota integrada: " + materiaSelecionada.getNotaIntegrada() + "\n"
                        + "Quantidade de faltas: " + materiaSelecionada.getQuantFalta() + "\n"
                        + "Media final: " + materiaSelecionada.getMedia() + "\n"
                        + "Situação: " + materiaSelecionada.getAprovado();
                
                return mensagem;
            
            }
        }
         return "Disciplina não encontrada";
    }

    public void adiciona(Disciplina nomeDisciplina) {
        this.listaDisciplinas.add(nomeDisciplina);
    }

    @Override
    public String toString() {
        return "Nome do aluno " + this.nome + "\n" + "RA: " + this.ra;
    }
}
