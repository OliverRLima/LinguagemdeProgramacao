/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio2;

import java.util.Random;

/**
 *
 * @author olive
 */
public class TesteTermometro {

    public static void main(String[] args) {
        Termometro termometro = new Termometro();
        Random gerador = new Random();

        termometro.aumentaTemperatura(15.0);
        termometro.diminuiTemperatura(15.0);

        Integer numeroAleatorio;
        Integer temperaturaAleatoria;

        System.out.println("Inicio do Teste");
        System.out.println("Temperatura atual em Celcius: " + termometro.getTemperaturaAtual() + "ºC");
        System.out.println("Temperatura atual em Fahreinheit: " + termometro.exibeFahreinheit() + "ºF");
        System.out.println("\n---------------------------------------------------------------------------");
        
        for (Integer contador = 0; contador < 7; contador++) {
            numeroAleatorio = gerador.nextInt(2);
            temperaturaAleatoria = gerador.nextInt(16);

            switch (numeroAleatorio) {
                case 0:
                    termometro.aumentaTemperatura(Double.valueOf(temperaturaAleatoria));
                    break;
                case 1:
                    termometro.diminuiTemperatura(Double.valueOf(temperaturaAleatoria));
                    break;
                default:
                    break;
            }
            System.out.println("\nTeste numero " + (contador + 1));
            System.out.println("Temperatura atual em Celcius: " + termometro.getTemperaturaAtual() + "ºC");
            System.out.println("Temperatura atual em Fahreinheit: " + termometro.exibeFahreinheit() + "ºF");
        }
        
        System.out.println("\n-----------------------------------------------------------------------------");
        System.out.println("\nFinal do teste");
        System.out.println("Temperatura máxima atingida: " + termometro.getTemperaturaMax() + "ºC");
        System.out.println("Temperatura minima atingida: " + termometro.getTemperaturaMin() + "ºC");
    }
}
