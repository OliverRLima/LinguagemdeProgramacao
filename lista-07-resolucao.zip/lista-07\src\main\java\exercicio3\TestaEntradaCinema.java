/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio3;

/**
 *
 * @author olive
 */
public class TestaEntradaCinema {
    public static void main(String[] args) {
        EntradaDeCinema cinema = new EntradaDeCinema();
        
        cinema.setHora(12);
        cinema.setNome("João e Maria");
        cinema.setSala(2);
        cinema.setValor(20);
        
        cinema.calculaDescontoHorario();
        cinema.calculaDesconto(16, true);
        
        System.out.println("O filme " + cinema.getNome() + " terá valor de entrada de R$" + cinema.getValor() +
                            ",00 na sala " + cinema.getSala() + " para clientes de 16 anos, estudante"
                            + " antes das 16:00 horas");
        
        EntradaDeCinema cinema2 = new EntradaDeCinema();
        
        cinema2.setHora(17);
        cinema2.setNome("Vingadores");
        cinema2.setSala(3);
        cinema2.setValor(25);
        
        cinema2.calculaDescontoHorario();
        cinema2.calculaDesconto(12, true);
        
        System.out.println("O filme " + cinema2.getNome() + " terá valor de entrada de R$" + cinema2.getValor() +
                            ",00 na sala " + cinema2.getSala() + " para clientes de 12 anos"
                            + " depois das 16:00 horas");
        
        EntradaDeCinema cinema3 = new EntradaDeCinema();
        
        cinema3.setHora(13);
        cinema3.setNome("Homem de Ferro");
        cinema3.setSala(4);
        cinema3.setValor(15);
        
        cinema3.calculaDescontoHorario();
        cinema2.calculaDesconto(20, false);
        
        System.out.println("O filme " + cinema3.getNome() + " terá valor de entrada de R$" + cinema3.getValor() +
                            ",00 na sala " + cinema3.getSala() + " para clientes de 20 anos, que não são estudantes"
                            + " antes das 16:00 horas");
        
        EntradaDeCinema cinema4 = new EntradaDeCinema();
        
        cinema4.setHora(20);
        cinema4.setNome("Vingadores Guerra Infinita");
        cinema4.setSala(5);
        cinema4.setValor(30);
        
        cinema4.calculaDescontoHorario();
        cinema4.calculaDesconto(14, true);
        
        System.out.println("O filme " + cinema4.getNome() + " terá valor de entrada de R$" + cinema4.getValor() +
                            ",00 na sala " + cinema4.getSala() + " para clientes entre 12 e 15 anos"
                            + " depois das 16:00 horas");
        
        EntradaDeCinema cinema5 = new EntradaDeCinema();
        
        cinema5.setHora(14);
        cinema5.setNome("Vingadores Ultimato");
        cinema5.setSala(6);
        cinema5.setValor(20);
        
        cinema5.calculaDescontoHorario();
        cinema5.calculaDesconto(25, true);
        
        System.out.println("O filme " + cinema5.getNome() + " terá valor de entrada de R$" + cinema5.getValor() +
                            ",00 na sala " + cinema5.getSala() + " para clientes acima de 20 anos"
                            + " antes das 16:00 horas");
    }
}
