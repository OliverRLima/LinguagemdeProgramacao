/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio1;

/**
 *
 * @author olive
 */
public class Empregado {
    private String nome;
    private String cargo;
    private Double salario;
    
    public void setSalario(Double salario){
        this.salario = salario;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
    
    public void setCargo(String cargo){
        this.cargo = cargo;
    }
    
    public void reajustarSalario(Double porcentagemReajuste){
        this.salario = this.salario + (this.salario * porcentagemReajuste);   
    }
    
    public String getNome(){
        return this.nome;
    }
    
    public String getCargo(){
        return this.cargo;
    }
    
    public Double getSalario(){
        return this.salario;
    }
}
