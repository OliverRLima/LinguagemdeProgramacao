/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio2;

/**
 *
 * @author olive
 */
public class Termometro {

    private Double temperaturaAtual = 0.0;
    private Double temperaturaMax = 0.0;
    private Double temperaturaMin = 0.0;

    public void aumentaTemperatura(Double valor) {
        this.temperaturaAtual += valor;

        if (this.temperaturaAtual > this.temperaturaMax) {
            this.temperaturaMax = this.temperaturaAtual;
        }
    }

    public void diminuiTemperatura(Double valor) {
        this.temperaturaAtual -= valor;

        if (this.temperaturaAtual < this.temperaturaMin) {
            this.temperaturaMin = this.temperaturaAtual;
        }
    }
    
    public Double exibeFahreinheit(){
        return (this.temperaturaAtual * 9/5) + 32;
    }
    
    public Double getTemperaturaAtual(){
        return this.temperaturaAtual;
    }
    
    public Double getTemperaturaMax(){
        return this.temperaturaMax;
    }
    
    public Double getTemperaturaMin(){
        return this.temperaturaMin;
    }
}
