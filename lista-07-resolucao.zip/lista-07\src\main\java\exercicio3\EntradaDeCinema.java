/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio3;

/**
 *
 * @author olive
 */
public class EntradaDeCinema {

    private Integer hora;
    private Integer sala;
    private Integer valor;
    private String nome;

    public void setHora(Integer hora) {
        this.hora = hora;
    }

    public void setSala(Integer sala) {
        this.sala = sala;
    }

    public void setValor(Integer valor) {
        this.valor = valor;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getHora() {
        return this.hora;
    }

    public Integer getSala() {
        return this.sala;
    }

    public Integer getValor() {
        return this.valor;
    }

    public String getNome() {
        return this.nome;
    }

    public void calculaDesconto(Integer idade, Boolean umEstudante) {
        if (idade <= 12) {

            this.valor = this.valor / 2;

        } else {
            if (umEstudante == true) {

                if (idade > 20) {
                    this.valor = this.valor - (2 * (this.valor / 10));
                } else if (idade > 16) {
                    this.valor = this.valor - (3 * (this.valor / 10));
                } else {
                    this.valor = this.valor - (4 * (this.valor / 10));
                }

            }

        }

    }

    public void calculaDescontoHorario() {

        if (this.hora < 16) {
            Integer valor = this.valor / 10;
            this.valor = this.valor - valor;
        }

    }

}
