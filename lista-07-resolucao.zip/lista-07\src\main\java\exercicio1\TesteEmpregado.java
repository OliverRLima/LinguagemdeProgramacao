/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio1;

/**
 *
 * @author olive
 */
public class TesteEmpregado {
    public static void main(String[] args) {
        Empregado primeiroEmpregado = new Empregado();
        Empregado segundoEmpregado = new Empregado();
        
        primeiroEmpregado.setNome("João");
        primeiroEmpregado.setSalario(5400.00);
        primeiroEmpregado.setCargo("Analista de Sistemas");
        
        segundoEmpregado.setNome("Maria");
        segundoEmpregado.setSalario(6000.00);
        segundoEmpregado.setCargo("Desenvolvedora");
        
        primeiroEmpregado.reajustarSalario(0.15);
        segundoEmpregado.reajustarSalario(0.10);
        
        System.out.println("Nome do empregado: " + primeiroEmpregado.getNome());
        System.out.println("Cargo do empregado: " + primeiroEmpregado.getCargo());
        System.out.println("Salário segundo reajuste de 15%: " + primeiroEmpregado.getSalario());
        
        System.out.println("--------------------------------------------------------------------");
        
        System.out.println("Nome do empregado: " + segundoEmpregado.getNome());
        System.out.println("Cargo do empregado: " + segundoEmpregado.getCargo());
        System.out.println("Salário segundo reajuste de 10%: " + segundoEmpregado.getSalario());
    }
}
