/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.projeto.cofrinho;

import java.awt.Color;
import java.util.Random;

/**
 *
 * @author Aluno
 */
public class Componentes {

    Random gerador = new Random();

    Integer variacao = 0;
    String cor = "";
    String status = "";
    
    void atualizarDados(){
        variacao = gerador.nextInt(101);
    }
    
    void mudarCorTexto() {
            
        if (variacao > 70) {
            cor = "#8b0000";
            status = "Crítico";
        } else if (variacao <= 20) {
            cor = "#120a8f";
            status = "Suave";
        } else {
            cor = "#c8a2c8";
            status = "Atencao";
        }
    }

}
