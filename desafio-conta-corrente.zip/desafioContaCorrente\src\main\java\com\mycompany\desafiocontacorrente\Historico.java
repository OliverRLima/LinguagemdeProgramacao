/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.desafiocontacorrente;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author olive
 */
public class Historico {

    private Integer dia;
    private Integer mes;
    private Integer ano;
    private Double valor;
    private String operacao;

    public Historico(Integer dia, Integer mes, Integer ano, Double valor, String operacao) {
        this.dia = dia;
        this.mes = mes;
        this.ano = ano;
        this.valor = valor;
        this.operacao = operacao;
    }

    public String getHistorico() {
        String extrato = String.format("\nHistórico de %s \nData efetivado: %d/%d/%d \nValor em questão: R$%.2f ",
                this.operacao, this.dia, this.mes, this.ano, this.valor);
        return extrato;
    }

    public Integer getDia() {
        return this.dia;
    }

    public Integer getMes() {
        return this.mes;
    }

    public Integer getAno() {
        return this.ano;
    }

    public String getOperacao() {
        return this.operacao;
    }

    @Override
    public String toString() {
        return String.format("Extrato %s com valor igual a R$%.2f", this.operacao, this.valor);
    }
}
