/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.desafiocontacorrente;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author olive
 */
public class ContaCorrente {

    private String titular;
    private Double saldo = 0.0;
    private List<Historico> listaHistoricos;

    public String getget(){
        String mensagem = "";
        for(Integer contador = 0; contador < listaHistoricos.size(); contador++){
            mensagem = String.valueOf(listaHistoricos.get(contador).getAno());
        }
        return mensagem;
    }
    
    public ContaCorrente(String titular) {
        this.listaHistoricos = new ArrayList<>();
        this.titular = titular;
    }

    public String depositar(Double valorADepositar, Integer dia, Integer mes, Integer ano) {
        if (valorADepositar > 0) {
            this.saldo += valorADepositar;
            Historico novoExtrato = new Historico(dia, mes, ano, valorADepositar, "deposito");
            listaHistoricos.add(novoExtrato);
            return "\nDeposito efetuado na conta do titular: " + this.titular;
        }
        
        return "Não foi possível depositar R$" + valorADepositar + " na conta do titular: " + this.titular; 
    }

    public String sacar(Double valorASacar, Integer dia, Integer mes, Integer ano) {
        if (valorASacar <= this.saldo) {
            this.saldo -= valorASacar;
            Historico novoExtrato = new Historico(dia, mes, ano, valorASacar, "saque");
            listaHistoricos.add(novoExtrato);
            return "\nSaque efetuado na conta do titular: " + this.titular;
        }
        
        return "Não foi possível sacar R$" + valorASacar + " na conta do titular: " + this.titular;
    }
    public String exibirExtrato(){
        return String.format("\nExtrato\nTitular da conta: %s\nValor em conta: R$%.2f", this.titular, this.saldo);
        
    }
    public String exibirHistorico(String operacao, Integer dia, Integer mes, Integer ano) {
        for (Integer contador = 0; contador < listaHistoricos.size(); contador++) {

            Historico extratoSelecionado = (Historico) listaHistoricos.get(contador);

            if (extratoSelecionado.getDia().equals(dia) && extratoSelecionado.getMes().equals(mes)) {
                if(extratoSelecionado.getAno().equals(ano) && extratoSelecionado.getOperacao().equals(operacao)){
                    String mensagem = extratoSelecionado.getHistorico();
                    return "\nTitular da conta: " + this.titular + mensagem;
                   
                }
            }
        }
        return "Não ocorreu saques ou depositos no dia inserido";
    }

    @Override
    public String toString() {
        return "Historico de saque ou depósito";
    }
}
