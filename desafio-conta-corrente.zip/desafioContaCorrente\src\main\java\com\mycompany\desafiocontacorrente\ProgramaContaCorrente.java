/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.desafiocontacorrente;

/**
 *
 * @author olive
 */
public class ProgramaContaCorrente {
    
    public static void main(String[] args) {
        
        ContaCorrente cc1 = new ContaCorrente("Diego Brito");
        ContaCorrente cc2 = new ContaCorrente("Célia Taniwaki");
        
        System.out.println(cc1.depositar(1000.0, 05, 02, 2020));
        System.out.println(cc1.exibirExtrato());
        
        System.out.println(cc1.sacar(300.0, 06, 02, 2020));
        
        System.out.println(cc1.sacar(600.0, 14, 02, 2020));
        
        System.out.println(cc1.depositar(1000.0, 20, 02, 2020));
        
        System.out.println(cc1.exibirExtrato());
        System.out.println(cc1.getget());
        
        System.out.println(cc1.exibirHistorico("saque", 14, 02, 2020));
        System.out.println(cc1.exibirHistorico("deposito", 20, 02, 2020));
        
        System.out.println(cc2.depositar(3500.0, 05, 02, 2020));
        System.out.println(cc2.exibirExtrato());
        
        System.out.println(cc2.exibirHistorico("deposito", 05, 02, 2020));
        
    }

}
